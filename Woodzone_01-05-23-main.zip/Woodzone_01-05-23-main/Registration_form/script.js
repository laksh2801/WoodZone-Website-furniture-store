function validateForm() {
    const password = document.getElementById('password').value;
    const retypePassword = document.getElementById('retypePassword').value;

    if (password !== retypePassword) {
        alert('Passwords do not match.');
        return false;
    }

    return true;
}
